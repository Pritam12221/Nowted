import { NavLink } from "react-router-dom";

const Navigation = () => {
  return (
    <div>
      <NavLink to="/folders">Recent</NavLink>
    </div>
  );
};

export default Navigation;
