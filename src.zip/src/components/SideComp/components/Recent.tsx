import { FileText } from "lucide-react";
import { useContext, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import type { Notes } from "../../../types/type";
import { GlobalContext } from "../../UI";
import RecentLoader from "../../SkeletonsLoaders/RecentLoader";

const Recent = () => {
  const [loading, setLoading] = useState(false);
  const data = useContext(GlobalContext);
  if (!data) {
    return;
  }
  const { fetchRecent, recent } = data;
  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      await fetchRecent();
      setLoading(false);
    };

    fetch();
  }, []);
  if (loading) return <RecentLoader />;
  return (
    <div className="w-full  pt-5">
      <h6 className=" text-bold px-10 pb-2">Recents</h6>
      <div className="flex flex-col gap-2">
        {recent.map((items: Notes) => (
          <NavLink
            key={items.id}
            to={`/${items.folder?.name}/${items.folder?.id}/notes/${items.id}`}
            className={({ isActive }) =>
              `w-full px-2 py-2 flex items-center gap-3 rounded transition-all  ${
                isActive ? "bg-primary-button-hover" : "hover:bg-zinc-700"
              }`
            }
          >
            <div className="flex px-6 gap-3 w-full">
              <FileText size={20} />
              <h6 className="self-center font-bold flex truncate">
                {items.title}
              </h6>
            </div>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default Recent;
